
Tronic Revamped - High-Res texture pack for Minecraft

CREDITS
	This texture pack is a compilation of several others:
	
	Tronic (http://evilmousestudios.com/tronic/) provides the terrain, actor and mob
		textures.
	Frenden's Texture Pack (http://www.minecraftforum.net/viewtopic.php?f=25&t=46707)
		provides the all the icons for tools, GUI etc.
	Painterly Pack (http://painterlypack.net/) provides the paintings, round sun and round
		moon textures.
	
	Thanks to Shamus03 for providing custom fire, water, lava, and portal textures, as well
	as the Connected Textures Mod texture slab.
	
	All other textures (including the new textures since Beta 1.2 of Minecraft) are the
	work of Desi Quintans (http://www.desiquintans.com).1

INSTRUCTIONS
	1)	Close Minecraft if it is running.
	2)	Put both Tronic Revamped .zips inside your Minecraft textures folder.
	3)	Download the HD Texture Fix and read its instructions.
	      http://www.minecraftforum.net/topic/232701-611-update173-compatible-mcpatcher-hd-fix-210-02/
	4)	Open the HD Texture Fix patcher. Check the box for 'Texture Pack' and select Either of
		the Tronic Revamped .zip files. Make sure the HD Textures box is checked, and then
		run the patcher.
	5)	Run Minecraft, select the Tronic Revamped pack you want to run from the texture list
		and play. If it doesn't work, delete minecraft.jar, restore your backup, and try again.